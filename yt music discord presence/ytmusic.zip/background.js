var musicOpen = false;
var intevalData = setInterval(checkTabs, 15000);

function updateRichPresence(songName, artistName, timeMax) {
    musicOpen = true;
    var data = {
        song: songName,
        artist: artistName,
        timeMax: timeMax
    };

    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://localhost:3000/",
        "method": "POST",
        "headers": {
            "content-type": "application/json"
        },
        "processData": false,
        "data": JSON.stringify(data)
    }

    $.ajax(settings)
}

function checkTabs() {
    browser.tabs.query({
            "url": "https://music.youtube.com/*"
        },
        function(result) {
            if (result.length == 0 && musicOpen) {
                cancelSession();
            }
        });
}

function cancelSession() {
    musicOpen = false;
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://localhost:3000/",
        "method": "POST",
        "headers": {
            "content-type": "application/json"
        },
        "processData": false,
        "data": JSON.stringify({
            end: true
        })
    }

    $.ajax(settings);
}

browser.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    browser.tabs.sendMessage(tabId, {
        message: 'send'
    });
});

browser.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    updateRichPresence(request.song, request.artist, request.timeMax)
});